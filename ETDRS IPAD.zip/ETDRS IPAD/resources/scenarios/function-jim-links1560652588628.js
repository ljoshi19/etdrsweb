(function(window, undefined) {

  var jimLinks = {
    "44d25095-2406-4530-8a53-fcc709b987b4" : {
      "Button-red_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button-red" : [
        "44d25095-2406-4530-8a53-fcc709b987b4"
      ]
    },
    "b241a48d-5e69-4b43-b581-a0252539b7f4" : {
      "Button" : [
        "6c2089d5-b8a5-4905-9d57-3fb653c37db4"
      ],
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "a4868478-6e03-43c1-97e2-16d75327b2be" : {
      "Button-red_1" : [
        "6c2089d5-b8a5-4905-9d57-3fb653c37db4"
      ]
    },
    "6c2089d5-b8a5-4905-9d57-3fb653c37db4" : {
      "Button-red" : [
        "a4868478-6e03-43c1-97e2-16d75327b2be"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);