jQuery("#simulation")
  .on("click", ".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Button-blue")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-blue > .backgroundLayer": {
                      "attributes": {
                        "border-top-color": "#80B8F1",
                        "border-right-color": "#80B8F1",
                        "border-bottom-color": "#80B8F1",
                        "border-left-color": "#80B8F1"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-blue span": {
                      "attributes": {
                        "color": "#80B8F1"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-blue": {
                      "attributes-ie": {
                        "border-top-color": "#80B8F1",
                        "border-right-color": "#80B8F1",
                        "border-bottom-color": "#80B8F1",
                        "border-left-color": "#80B8F1"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-blue > .backgroundLayer": {
                      "attributes": {
                        "border-top-color": "#157EFB",
                        "border-right-color": "#157EFB",
                        "border-bottom-color": "#157EFB",
                        "border-left-color": "#157EFB"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-blue span": {
                      "attributes": {
                        "color": "#157EFB"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-blue": {
                      "attributes-ie": {
                        "border-top-color": "#157EFB",
                        "border-right-color": "#157EFB",
                        "border-bottom-color": "#157EFB",
                        "border-left-color": "#157EFB"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 300
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_1" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_1",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_2" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_2",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_3" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_3",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_4" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_4",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_5" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_5",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_6" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_6",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_7" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_7",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_8" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_8",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_9" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_9",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_10" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_10",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_11" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_11",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_12" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_12",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_13" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_13",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_14" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_14",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL" ],
                    "value": {
                      "action": "jimPlus",
                      "parameter": [ {
                        "action": "jimPlus",
                        "parameter": [ {
                          "action": "jimPlus",
                          "parameter": [ {
                            "action": "jimPlus",
                            "parameter": [ {
                              "action": "jimPlus",
                              "parameter": [ {
                                "datatype": "property",
                                "target": "#s-TOTAL_1",
                                "property": "jimGetValue"
                              },{
                                "datatype": "property",
                                "target": "#s-TOTAL_2",
                                "property": "jimGetValue"
                              } ]
                            },{
                              "datatype": "property",
                              "target": "#s-TOTAL_3",
                              "property": "jimGetValue"
                            } ]
                          },{
                            "datatype": "property",
                            "target": "#s-TOTAL_4",
                            "property": "jimGetValue"
                          } ]
                        },{
                          "action": "jimPlus",
                          "parameter": [ {
                            "datatype": "property",
                            "target": "#s-TOTAL_5",
                            "property": "jimGetValue"
                          },{
                            "action": "jimPlus",
                            "parameter": [ {
                              "action": "jimPlus",
                              "parameter": [ {
                                "datatype": "property",
                                "target": "#s-TOTAL_6",
                                "property": "jimGetValue"
                              },{
                                "datatype": "property",
                                "target": "#s-TOTAL_7",
                                "property": "jimGetValue"
                              } ]
                            },{
                              "action": "jimPlus",
                              "parameter": [ {
                                "action": "jimPlus",
                                "parameter": [ {
                                  "action": "jimPlus",
                                  "parameter": [ {
                                    "action": "jimPlus",
                                    "parameter": [ {
                                      "datatype": "property",
                                      "target": "#s-TOTAL_8",
                                      "property": "jimGetValue"
                                    },{
                                      "action": "jimPlus",
                                      "parameter": [ {
                                        "action": "jimPlus",
                                        "parameter": [ {
                                          "datatype": "property",
                                          "target": "#s-TOTAL_9",
                                          "property": "jimGetValue"
                                        },{
                                          "datatype": "property",
                                          "target": "#s-TOTAL_10",
                                          "property": "jimGetValue"
                                        } ]
                                      },{
                                        "datatype": "property",
                                        "target": "#s-TOTAL_11",
                                        "property": "jimGetValue"
                                      } ]
                                    } ]
                                  },{
                                    "datatype": "property",
                                    "target": "#s-TOTAL_12",
                                    "property": "jimGetValue"
                                  } ]
                                },{
                                  "datatype": "property",
                                  "target": "#s-TOTAL_13",
                                  "property": "jimGetValue"
                                } ]
                              },{
                                "datatype": "property",
                                "target": "#s-TOTAL_14",
                                "property": "jimGetValue"
                              } ]
                            } ]
                          } ]
                        } ]
                      },"20" ]
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button-red")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-red > .backgroundLayer": {
                      "attributes": {
                        "border-top-color": "#FD999A",
                        "border-right-color": "#FD999A",
                        "border-bottom-color": "#FD999A",
                        "border-left-color": "#FD999A"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-red span": {
                      "attributes": {
                        "color": "#FD999A"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-red": {
                      "attributes-ie": {
                        "border-top-color": "#FD999A",
                        "border-right-color": "#FD999A",
                        "border-bottom-color": "#FD999A",
                        "border-left-color": "#FD999A"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-red > .backgroundLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-style": "solid",
                        "border-top-color": "#DD3214",
                        "border-right-width": "1px",
                        "border-right-style": "solid",
                        "border-right-color": "#DD3214",
                        "border-bottom-width": "1px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#DD3214",
                        "border-left-width": "1px",
                        "border-left-style": "solid",
                        "border-left-color": "#DD3214",
                        "border-radius": "12px 12px 12px 12px"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-red": {
                      "attributes": {
                        "font-size": "11.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-red .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "center"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-red span": {
                      "attributes": {
                        "color": "#DD3214",
                        "text-align": "center",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "11.0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-red": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-style": "solid",
                        "border-top-color": "#DD3214",
                        "border-right-width": "1px",
                        "border-right-style": "solid",
                        "border-right-color": "#DD3214",
                        "border-bottom-width": "1px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#DD3214",
                        "border-left-width": "1px",
                        "border-left-style": "solid",
                        "border-left-color": "#DD3214",
                        "border-radius": "12px 12px 12px 12px"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 300
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/44d25095-2406-4530-8a53-fcc709b987b4"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button-red_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-red_1 > .backgroundLayer": {
                      "attributes": {
                        "border-top-color": "#FD999A",
                        "border-right-color": "#FD999A",
                        "border-bottom-color": "#FD999A",
                        "border-left-color": "#FD999A"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-red_1 span": {
                      "attributes": {
                        "color": "#FD999A"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-red_1": {
                      "attributes-ie": {
                        "border-top-color": "#FD999A",
                        "border-right-color": "#FD999A",
                        "border-bottom-color": "#FD999A",
                        "border-left-color": "#FD999A"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-red_1 > .backgroundLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-style": "solid",
                        "border-top-color": "#DD3214",
                        "border-right-width": "1px",
                        "border-right-style": "solid",
                        "border-right-color": "#DD3214",
                        "border-bottom-width": "1px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#DD3214",
                        "border-left-width": "1px",
                        "border-left-style": "solid",
                        "border-left-color": "#DD3214",
                        "border-radius": "5px 5px 5px 5px"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-red_1": {
                      "attributes": {
                        "font-size": "11.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-red_1 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "center"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-red_1 span": {
                      "attributes": {
                        "color": "#DD3214",
                        "text-align": "center",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "11.0pt"
                      }
                    }
                  },{
                    "#s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Button-red_1": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-style": "solid",
                        "border-top-color": "#DD3214",
                        "border-right-width": "1px",
                        "border-right-style": "solid",
                        "border-right-color": "#DD3214",
                        "border-bottom-width": "1px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#DD3214",
                        "border-left-width": "1px",
                        "border-left-style": "solid",
                        "border-left-color": "#DD3214",
                        "border-radius": "5px 5px 5px 5px"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 300
                },
                {
                  "action": "jimSetSelection",
                  "parameter": {
                    "target": [ "#s-Line_1" ],
                    "value": ""
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetSelection",
                  "parameter": {
                    "target": [ "#s-Line_2" ],
                    "value": ""
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetSelection",
                  "parameter": {
                    "target": [ "#s-Line_3" ],
                    "value": ""
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetSelection",
                  "parameter": {
                    "target": [ "#s-Line_4" ],
                    "value": ""
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetSelection",
                  "parameter": {
                    "target": [ "#s-Line_5" ],
                    "value": ""
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetSelection",
                  "parameter": {
                    "target": [ "#s-Line_6" ],
                    "value": ""
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetSelection",
                  "parameter": {
                    "target": [ "#s-Line_7" ],
                    "value": ""
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetSelection",
                  "parameter": {
                    "target": [ "#s-Line_8" ],
                    "value": ""
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetSelection",
                  "parameter": {
                    "target": [ "#s-Line_9" ],
                    "value": ""
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetSelection",
                  "parameter": {
                    "target": [ "#s-Line_10" ],
                    "value": ""
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetSelection",
                  "parameter": {
                    "target": [ "#s-Line_11" ],
                    "value": ""
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetSelection",
                  "parameter": {
                    "target": [ "#s-Line_12" ],
                    "value": ""
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetSelection",
                  "parameter": {
                    "target": [ "#s-Line_13" ],
                    "value": ""
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetSelection",
                  "parameter": {
                    "target": [ "#s-Line_14" ],
                    "value": ""
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL" ],
                    "value": ""
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("click", ".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .toggle", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Ok-green")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_1" ],
                      "value": "C,O,H,Z,V"
                    },
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_1" ],
                      "value": ""
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Ok-green_1")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_2" ],
                      "value": "S,Z,N,D,C"
                    },
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_2" ],
                      "value": ""
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Ok-green_2")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_3" ],
                      "value": "V,K,C,N,R"
                    },
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_3" ],
                      "value": ""
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Ok-green_3")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_4" ],
                      "value": "K,C,R,H,N"
                    },
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_4" ],
                      "value": ""
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Ok-green_4")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_5" ],
                      "value": "Z,K,D,V,C"
                    },
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_5" ],
                      "value": ""
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Ok-green_5")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_6" ],
                      "value": "H,V,O,R,K"
                    },
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_6" ],
                      "value": ""
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Ok-green_6")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_7" ],
                      "value": "R,H,S,O,N"
                    },
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_7" ],
                      "value": ""
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Ok-green_7")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_8" ],
                      "value": "K,S,V,R,H"
                    },
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_8" ],
                      "value": ""
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Ok-green_8")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_9" ],
                      "value": "H,N,K,C,D"
                    },
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_9" ],
                      "value": ""
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Ok-green_9")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_10" ],
                      "value": "N,D,V,K,O"
                    },
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_10" ],
                      "value": ""
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Ok-green_10")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_11" ],
                      "value": "D,H,O,S,Z"
                    },
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_11" ],
                      "value": ""
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Ok-green_11")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_12" ],
                      "value": "V,R,N,D,O"
                    },
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_12" ],
                      "value": ""
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Ok-green_12")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_13" ],
                      "value": "C,Z,H,K,S"
                    },
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_13" ],
                      "value": ""
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Ok-green_13")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_14" ],
                      "value": "O,R,Z,S,K"
                    },
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_14" ],
                      "value": ""
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    }
  })
  .on("variablechange.jim", ".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .variablechange", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-TOTAL_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_1" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_1",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-TOTAL_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_2" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_2",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-TOTAL_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_3" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_3",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-TOTAL_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_4" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_4",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-TOTAL_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_5" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_5",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-TOTAL_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_6" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_6",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-TOTAL_7")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_7" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_7",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-TOTAL_8")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_8" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_8",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-TOTAL_9")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_9" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_9",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-TOTAL_10")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_10" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_10",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-TOTAL_11")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_11" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_11",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-TOTAL_12")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_12" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_12",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-TOTAL_13")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_13" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_13",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-TOTAL_14")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_14" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_14",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });