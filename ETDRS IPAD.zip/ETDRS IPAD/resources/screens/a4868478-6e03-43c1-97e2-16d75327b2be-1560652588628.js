jQuery("#simulation")
  .on("click", ".s-a4868478-6e03-43c1-97e2-16d75327b2be .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Button-red_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-a4868478-6e03-43c1-97e2-16d75327b2be #s-Button-red_1 > .backgroundLayer": {
                      "attributes": {
                        "border-top-color": "#FD999A",
                        "border-right-color": "#FD999A",
                        "border-bottom-color": "#FD999A",
                        "border-left-color": "#FD999A"
                      }
                    }
                  },{
                    "#s-a4868478-6e03-43c1-97e2-16d75327b2be #s-Button-red_1 span": {
                      "attributes": {
                        "color": "#FD999A"
                      }
                    }
                  },{
                    "#s-a4868478-6e03-43c1-97e2-16d75327b2be #s-Button-red_1": {
                      "attributes-ie": {
                        "border-top-color": "#FD999A",
                        "border-right-color": "#FD999A",
                        "border-bottom-color": "#FD999A",
                        "border-left-color": "#FD999A"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-a4868478-6e03-43c1-97e2-16d75327b2be #s-Button-red_1 > .backgroundLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-style": "solid",
                        "border-top-color": "#DD3214",
                        "border-right-width": "1px",
                        "border-right-style": "solid",
                        "border-right-color": "#DD3214",
                        "border-bottom-width": "1px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#DD3214",
                        "border-left-width": "1px",
                        "border-left-style": "solid",
                        "border-left-color": "#DD3214",
                        "border-radius": "5px 5px 5px 5px"
                      }
                    }
                  },{
                    "#s-a4868478-6e03-43c1-97e2-16d75327b2be #s-Button-red_1": {
                      "attributes": {
                        "font-size": "11.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-a4868478-6e03-43c1-97e2-16d75327b2be #s-Button-red_1 .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "center"
                      }
                    }
                  },{
                    "#s-a4868478-6e03-43c1-97e2-16d75327b2be #s-Button-red_1 span": {
                      "attributes": {
                        "color": "#DD3214",
                        "text-align": "center",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "11.0pt"
                      }
                    }
                  },{
                    "#s-a4868478-6e03-43c1-97e2-16d75327b2be #s-Button-red_1": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-style": "solid",
                        "border-top-color": "#DD3214",
                        "border-right-width": "1px",
                        "border-right-style": "solid",
                        "border-right-color": "#DD3214",
                        "border-bottom-width": "1px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#DD3214",
                        "border-left-width": "1px",
                        "border-left-style": "solid",
                        "border-left-color": "#DD3214",
                        "border-radius": "5px 5px 5px 5px"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 300
                },
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/6c2089d5-b8a5-4905-9d57-3fb653c37db4"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button-blue")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-a4868478-6e03-43c1-97e2-16d75327b2be #s-Button-blue > .backgroundLayer": {
                      "attributes": {
                        "border-top-color": "#80B8F1",
                        "border-right-color": "#80B8F1",
                        "border-bottom-color": "#80B8F1",
                        "border-left-color": "#80B8F1"
                      }
                    }
                  },{
                    "#s-a4868478-6e03-43c1-97e2-16d75327b2be #s-Button-blue span": {
                      "attributes": {
                        "color": "#80B8F1"
                      }
                    }
                  },{
                    "#s-a4868478-6e03-43c1-97e2-16d75327b2be #s-Button-blue": {
                      "attributes-ie": {
                        "border-top-color": "#80B8F1",
                        "border-right-color": "#80B8F1",
                        "border-bottom-color": "#80B8F1",
                        "border-left-color": "#80B8F1"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-a4868478-6e03-43c1-97e2-16d75327b2be #s-Button-blue > .backgroundLayer": {
                      "attributes": {
                        "border-top-color": "#157EFB",
                        "border-right-color": "#157EFB",
                        "border-bottom-color": "#157EFB",
                        "border-left-color": "#157EFB"
                      }
                    }
                  },{
                    "#s-a4868478-6e03-43c1-97e2-16d75327b2be #s-Button-blue span": {
                      "attributes": {
                        "color": "#157EFB"
                      }
                    }
                  },{
                    "#s-a4868478-6e03-43c1-97e2-16d75327b2be #s-Button-blue": {
                      "attributes-ie": {
                        "border-top-color": "#157EFB",
                        "border-right-color": "#157EFB",
                        "border-bottom-color": "#157EFB",
                        "border-left-color": "#157EFB"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 300
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_1" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_1",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_2" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_2",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_3" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_3",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL" ],
                    "value": {
                      "action": "jimPlus",
                      "parameter": [ {
                        "action": "jimPlus",
                        "parameter": [ {
                          "datatype": "property",
                          "target": "#s-TOTAL_1",
                          "property": "jimGetValue"
                        },{
                          "datatype": "property",
                          "target": "#s-TOTAL_2",
                          "property": "jimGetValue"
                        } ]
                      },{
                        "datatype": "property",
                        "target": "#s-TOTAL_3",
                        "property": "jimGetValue"
                      } ]
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("click", ".s-a4868478-6e03-43c1-97e2-16d75327b2be .toggle", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Ok-green")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_1" ],
                      "value": "C,O,H,Z,V"
                    },
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_1" ],
                      "value": ""
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Ok-green_1")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_2" ],
                      "value": "S,Z,N,D,C"
                    },
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_2" ],
                      "value": ""
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    } else if(jFirer.is("#s-Ok-green_2")) {
      if(jFirer.data("jimHasToggle")) {
        jFirer.removeData("jimHasToggle");
        jEvent.undoCases(jFirer);
      } else {
        jFirer.data("jimHasToggle", true);
        event.backupState = true;
        event.target = jFirer;
        cases = [
          {
            "blocks": [
              {
                "actions": [
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_3" ],
                      "value": "V,K,C,N,R"
                    },
                    "exectype": "serial",
                    "delay": 0
                  },
                  {
                    "action": "jimSetSelection",
                    "parameter": {
                      "target": [ "#s-Line_3" ],
                      "value": ""
                    },
                    "exectype": "serial",
                    "delay": 0
                  }
                ]
              }
            ],
            "exectype": "serial",
            "delay": 0
          }
        ];
        jEvent.launchCases(cases);
      }
    }
  })
  .on("variablechange.jim", ".s-a4868478-6e03-43c1-97e2-16d75327b2be .variablechange", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-TOTAL_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_1" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_1",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-TOTAL_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_2" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_2",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-TOTAL_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-TOTAL_3" ],
                    "value": {
                      "action": "jimCountData",
                      "parameter": {
                        "datatype": "property",
                        "target": "#s-Line_3",
                        "property": "jimGetSelectedValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });