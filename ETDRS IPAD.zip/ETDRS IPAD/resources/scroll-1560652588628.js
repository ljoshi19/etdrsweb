(function(window, undefined) {

    /*********************** START STATIC ACCESS METHODS ************************/

    jQuery.extend(jimUtil, {
        "loadScrollBars": function() {
            jQuery(".s-44d25095-2406-4530-8a53-fcc709b987b4 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-44d25095-2406-4530-8a53-fcc709b987b4 #s-Line_1 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-44d25095-2406-4530-8a53-fcc709b987b4 #s-Line_2 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-44d25095-2406-4530-8a53-fcc709b987b4 #s-Line_3 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Line_1 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Line_2 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Line_3 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Line_4 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Line_5 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Line_6 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Line_7 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Line_8 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Line_9 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Line_10 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Line_11 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Line_12 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Line_13 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Line_14 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-b241a48d-5e69-4b43-b581-a0252539b7f4 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-a4868478-6e03-43c1-97e2-16d75327b2be .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-a4868478-6e03-43c1-97e2-16d75327b2be #s-Line_1 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-a4868478-6e03-43c1-97e2-16d75327b2be #s-Line_2 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-a4868478-6e03-43c1-97e2-16d75327b2be #s-Line_3 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-6c2089d5-b8a5-4905-9d57-3fb653c37db4 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-6c2089d5-b8a5-4905-9d57-3fb653c37db4 #s-Line_1 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-6c2089d5-b8a5-4905-9d57-3fb653c37db4 #s-Line_2 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-6c2089d5-b8a5-4905-9d57-3fb653c37db4 #s-Line_3 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-6c2089d5-b8a5-4905-9d57-3fb653c37db4 #s-Line_4 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-6c2089d5-b8a5-4905-9d57-3fb653c37db4 #s-Line_5 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-6c2089d5-b8a5-4905-9d57-3fb653c37db4 #s-Line_6 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-6c2089d5-b8a5-4905-9d57-3fb653c37db4 #s-Line_7 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-6c2089d5-b8a5-4905-9d57-3fb653c37db4 #s-Line_8 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-6c2089d5-b8a5-4905-9d57-3fb653c37db4 #s-Line_9 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-6c2089d5-b8a5-4905-9d57-3fb653c37db4 #s-Line_10 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-6c2089d5-b8a5-4905-9d57-3fb653c37db4 #s-Line_11 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-6c2089d5-b8a5-4905-9d57-3fb653c37db4 #s-Line_12 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-6c2089d5-b8a5-4905-9d57-3fb653c37db4 #s-Line_13 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
            jQuery(".s-6c2089d5-b8a5-4905-9d57-3fb653c37db4 #s-Line_14 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:true, backgroundColor:'black', opacity:'0.5', thickness:'2'});
         }
    });

    /*********************** END STATIC ACCESS METHODS ************************/

}) (window);